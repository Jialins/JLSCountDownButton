//
//  JLSCountDownButton.h
//  JLSCountDownButton
//
//  Created by jialins on 16/9/14.
//  Copyright © 2016年 jialins. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JLSCountDownButton;
typedef void (^DidChangeBlock)(JLSCountDownButton *countDownButton,NSInteger second);
typedef void (^DidFinishedBlock)(JLSCountDownButton *countDownButton,NSInteger second);
typedef void (^IsCountDownBlock)(JLSCountDownButton *countDownButton);

@interface JLSCountDownButton : UIButton

//验证码倒计时时长
@property (nonatomic, assign) NSInteger durationOfCountDown;

//原始的字体颜色
@property (nonatomic,strong) UIColor *originalColor;

//设置按钮的默认标题（默认为“获取验证码”）
@property (nonatomic, strong) NSString *defaultTitle;

//设置按钮倒计时的标题(默认为“重新发送 + 剩余时间”)
@property (nonatomic, strong) NSString *countDownTitle;

//倒计时时候的字体颜色
@property (nonatomic,strong) UIColor *processColor;

// 倒计时进行中的时候的回调
@property (nonatomic, copy)  DidChangeBlock didChangeBlock;

//倒计时结束时的回调
@property (nonatomic, copy) DidFinishedBlock didFinishedBlock;

//正在倒计时的回调
@property (nonatomic, copy)IsCountDownBlock isCountDownBlock;

/** 倒计时进行中的时候的回调 */
-(void)didChange:(DidChangeBlock)didChangeBlock;

/** 倒计时结束时的回调 */
-(void)didFinished:(DidFinishedBlock)didFinishedBlock;

/** 正在倒计时的回调 */
-(void)isCountDown:(IsCountDownBlock)isCountDownBlock;



@end
