//
//  ViewController.m
//  JLSCountDownButton
//
//  Created by jialins on 16/9/14.
//  Copyright © 2016年 jialins. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.jlsCountDownButton.frame = CGRectMake(self.view.frame.size.width*0.5-40, self.view.frame.size.height*0.5-20, 80, 40);
    self.jlsCountDownButton.originalColor = [UIColor purpleColor];
    
    self.jlsCountDownButton.processColor = [UIColor greenColor];
    
    self.jlsCountDownButton.durationOfCountDown = 10;
    
    self.jlsCountDownButton.backgroundColor = [UIColor redColor];
    
    self.jlsCountDownButton.titleLabel.font = [UIFont systemFontOfSize:12.0f];
    
    [self.view addSubview:self.jlsCountDownButton];
    
    [self.jlsCountDownButton isCountDown:^(JLSCountDownButton *countDownButton) {
        NSLog(@"还没完呢--------------");
        countDownButton.enabled = NO;
    }];
    
    [self.jlsCountDownButton didFinished:^(JLSCountDownButton *countDownButton, NSInteger second) {
        countDownButton.enabled = YES;
    }];
    
    [self.jlsCountDownButton didChange:^(JLSCountDownButton *countDownButton, NSInteger second) {
        NSLog(@"-----------------second:%ld",(long)second);
    }];
    
}

#pragma mark - 懒加载
- (JLSCountDownButton *)jlsCountDownButton
{
    if (!_jlsCountDownButton) {
        _jlsCountDownButton = [[JLSCountDownButton alloc] init];
    }
    return _jlsCountDownButton;
}


@end
