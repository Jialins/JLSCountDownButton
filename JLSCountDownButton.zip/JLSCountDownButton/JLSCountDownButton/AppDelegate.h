//
//  AppDelegate.h
//  JLSCountDownButton
//
//  Created by jialins on 16/9/14.
//  Copyright © 2016年 jialins. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

