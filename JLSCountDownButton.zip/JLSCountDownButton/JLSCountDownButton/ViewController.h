//
//  ViewController.h
//  JLSCountDownButton
//
//  Created by jialins on 16/9/14.
//  Copyright © 2016年 jialins. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JLSCountDownButton.h"

@interface ViewController : UIViewController
@property (nonatomic, strong)JLSCountDownButton *jlsCountDownButton;
@end

